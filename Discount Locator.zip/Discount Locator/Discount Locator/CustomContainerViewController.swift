//
//  CustomContainerViewController.swift
//  Discount Locator
//
//  Created by Faculty of Organisation and Informatics on 18/12/15.
//  Copyright © 2015 air. All rights reserved.
//

import UIKit

class CustomContainerViewController: UIViewController {

        
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}