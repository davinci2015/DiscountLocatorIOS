//
//  TwoViewController.swift
//  Discount Locator
//
//  Created by Faculty of Organisation and Informatics on 18/12/15.
//  Copyright © 2015 air. All rights reserved.
//

import Cocoa

class TwoViewController: UIViewController {

}
