//
//  core.h
//  core
//
//  Created by Faculty of Organisation and Informatics on 13/11/15.
//  Copyright © 2015 air. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for core.
FOUNDATION_EXPORT double coreVersionNumber;

//! Project version string for core.
FOUNDATION_EXPORT const unsigned char coreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <core/PublicHeader.h>


