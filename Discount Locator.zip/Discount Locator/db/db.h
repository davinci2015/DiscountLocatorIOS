//
//  db.h
//  db
//
//  Created by Faculty of Organisation and Informatics on 10/11/15.
//  Copyright © 2015 air. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for db.
FOUNDATION_EXPORT double dbVersionNumber;

//! Project version string for db.
FOUNDATION_EXPORT const unsigned char dbVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <db/PublicHeader.h>


