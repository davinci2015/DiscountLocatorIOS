//
//  StoreCategories.swift
//  Discount Locator
//
//  Created by MTLab on 05/11/15.
//  Copyright © 2015 air. All rights reserved.
//

import Foundation

import RealmSwift

class StoreCategories: Object
{
    dynamic var storeId: Int = 0
    
    dynamic var categoryId: Int = 0
}